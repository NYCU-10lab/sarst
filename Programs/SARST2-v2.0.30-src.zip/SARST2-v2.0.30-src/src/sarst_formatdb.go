package main

import (
  "lo"
  "strings"
  . "lo/bio/prot/stru/algos"
)


var gbl_self             = "." + lo.PathSep + "formatdb"

var usr_db_targetDb      = NULL
var usr_flist_file       = NULL
var usr_save_disk        = false
var usr_keep_order       = false
var usr_split_subDbSize  = -1
var usr_t_numThreads     = 0

var Usr_SbjPdbFilesPats  []string



func RemoveOldFiles() {
  OldFiles := lo.Glob(usr_db_targetDb + ".dat")
  OldFiles  = append( OldFiles, lo.Glob(usr_db_targetDb + ".ent"  )... )
  OldFiles  = append( OldFiles, lo.Glob(usr_db_targetDb + ".srt"  )... )
  OldFiles  = append( OldFiles, lo.Glob(usr_db_targetDb + ".seq"  )... )
  OldFiles  = append( OldFiles, lo.Glob(usr_db_targetDb + ".caf"  )... )
  OldFiles  = append( OldFiles, lo.Glob(usr_db_targetDb + ".clr"  )... )
  OldFiles  = append( OldFiles, lo.Glob(usr_db_targetDb + "-*.ver")... )
  OldFiles  = append( OldFiles, lo.Glob(usr_db_targetDb + "-*.dat")... )
  OldFiles  = append( OldFiles, lo.Glob(usr_db_targetDb + "-*.ent")... )
  OldFiles  = append( OldFiles, lo.Glob(usr_db_targetDb + "-*.srt")... )
  OldFiles  = append( OldFiles, lo.Glob(usr_db_targetDb + "-*.seq")... )
  OldFiles  = append( OldFiles, lo.Glob(usr_db_targetDb + "-*.caf")... )
  OldFiles  = append( OldFiles, lo.Glob(usr_db_targetDb + "-*.clr")... )

  for _, oldFile := range OldFiles { lo.Remove(oldFile) }
}



func main() {
  if UsrSettings := ProcessArgs();
     !CheckSettings(UsrSettings) { Bye(gbl_errMsg) }

  RemoveOldFiles()

  lo.ErrorReporting = 0

  Gbl_Output.WriteString(gbl_declaration_brief + br)
  Gbl_Output.Flush()


  Settings := map[string]any{
    `targetDb`     : usr_db_targetDb,
    `numThreads`   : usr_t_numThreads,
    `subDbSize`    : usr_split_subDbSize,
    `savingDisk`   : usr_save_disk,
    `keepingOrder` : usr_keep_order,
  }

  SR := FormatDB(Usr_SbjPdbFilesPats, Settings, Gbl_Output)
  Gbl_Output.Flush()

  if SR.ErrMsg() != "" { Bye( SR.ErrMsg() ) }


  //###
  var flist string
  if len(Usr_SbjPdbFilesPats) <= 5 {
    flist = strings.ReplaceAll( strings.Join(Usr_SbjPdbFilesPats, ", "), ", " + NULL, "" )
  } else {
    flist = strings.ReplaceAll( strings.Join(Usr_SbjPdbFilesPats[0:5], ", ") + ", ...", ", " + NULL, "" )
  }
  
  Gbl_Output.WriteString( lo.Sprintf(  br + br +
    "Subjects: %s"                   + br +
    "Dataset size = %s structure(s)" + br + br,
    flist,
    lo.FormatNumber( float64( SR.NumTotalSbjs() ), 0 ),
  ) )
  Gbl_Output.Flush()


  //###
  lo.Cprint( YELLOW, lo.Sprintf( "Running time: %.4f sec" + br, lo.Timefrom(gbl_time_init) ) )
}
