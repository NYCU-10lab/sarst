package main


const HTML_RESULTS = `<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<!--
%v
-->
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>SARST2</title>

  <style type="text/css">
    .lnk {
      color: #0000FF;
    }
    .lnk:hover {
      cursor :pointer;
      text-decoration: underline;
    }
  </style>

  <script language="JavaScript">
    function gotoPage(pno) {
      if (pno < 1) { pno = 1; }
      if (pno > %v) { pno = %v; }
      document.getElementById('page').src = "SarstResults-" + pno + ".html";
      document.getElementById('p').value  = pno;
    }
  </script>
</head>

<body>
<table width="100%%" height="100%%" cellpadding="0" cellspacing="1" bgcolor="#666666">
  <tr bgcolor="#FFFFFF"> 
    <td height="74" colspan="2">
      <table width="100%%" height="100%%">
        <tr> 
          <td>
            <p>
              <font size="5">
                <strong>SARST2: Structural similarity search Aided by Ramachandran Sequential Transformation</strong>
              </font><br>
              <font size="2">%v</font>
            </p>
          </td>
          <td width="23%%" nowrap>
            <font size="2">
              Please cite our paper(s) should you find this software helpful,<br>
              1. Wei-Cheng Lo, et al. (2007). BMC Bioinformatics, 8:307<br>
              2. Wei-Cheng Lo, et al. (2009). Nucleic Acids Research, 37:W545-551
            </font>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr bgcolor="#FFFFFF"> 
    <td width="36%%" height="23%%" valign="top" style="padding:7px">
      <font face="Arial" style="font-size:0.96em;">
        <form name="form1" method="post" action="" onSubmit="gotoPage(p.value);return false;">
            <a class="lnk" onClick="document.getElementById('sup').src='SarstResults-sup.html';"><b>## Query: %v</b></a><br>
            Protein size = %-*v residues
            <p>
              Subjects:<br>
              Dataset size = %v structure(s)
            </p>
            <p>
              %v
            </p>
            <p>
            </a><a class="lnk" onClick="gotoPage( parseInt(p.value)-1 );">&lt;&lt;</a> 
            Page 
            <input name="p" id="p" type="text" size="7" value="1" style="text-align:center;">
              <input type="button" name="Go" value="Go" onClick="gotoPage(p.value);">
              <a class="lnk" onClick="gotoPage( parseInt(p.value)+1 );">&gt;&gt;</a>
            </p>
        </form>
        <div style="bottom:3px;right:3px;font-size:0.80em;text-align:right;">
          See <a href="https://wiki.jmol.org/index.php/Troubleshooting/Local_Files" target="page">Jmol Wiki</a>
          if the structure cannot be displayed.<br>
          The structure will be purely in red for perfect superimposition.
        </div>
      </font>
    </td>
    <td width="64%%" rowspan="2" valign="top">
      <table width="100%%" height="100%%" cellpadding="0" cellspacing="1" bgcolor="#666666">
        <tr bgcolor="#FFFFFF"> 
          <td width="100%%" height="50%%">
            <iframe name="summ" id="summ" src="SarstResults-sum.html" width="100%%" height="100%%" border="0" style="border:none;"></iframe>
          </td>
        </tr>
        <tr bgcolor="#FFFFFF"> 
          <td height="50%%">
            <iframe name="page" id="page" src="SarstResults-1.html" width="100%%" height="100%%" border="0" style="border:none;"></iframe>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr bgcolor="#FFFFFF"> 
    <td height="69%%" valign="top">
      <iframe name="sup" id="sup" src="SarstResults-sup.html" width="100%%" height="100%%" border="0" style="border:none;"></iframe>
    </td>
  </tr>
</table>
</body>
</html>
`

const HTML_SUP = `<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<!--
%v
-->
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>SARST2</title>

  <script type="text/javascript" src="%v/JSmol.min.js"></script>
  <script type="text/javascript" src="%v/js/JSmolThree.js"></script>
  <script type="text/javascript" src="%v/js/JSmolGLmol.js"></script>
  <script type="text/javascript">
    let urlParams = new URLSearchParams(window.location.search);
    var mode = urlParams.get("m");
    var stru = urlParams.get("s");

    var struFile = "Qry.pdb"
    if (stru != null && stru != "") {
      struFile = "Qry-Sbj" + stru + ".pdb"
    } else {
      stru = ""
    }

    var jmolApplet_qsSup;

    var use = ( mode ? mode : "HTML5" );
    var s   = document.location.search;

    Jmol._debugCode = ( s.indexOf("debugcode") >= 0 );
    jmol_isReady    = function(applet) {}

    script_qsSup    = 'load sup/' + struFile + '; background white; set ambient 10; restrict none; select :Q; color blue; cartoons; select :S; color red; cartoons';

    var Info_qsSup  = {
      width                 : "90%%",
      height                : "90%%",
      debug                 : false,
      color                 : "white",
      addSelectionOptions   : false,
      use                   : use,
      j2sPath               : "%v/j2s",
      serverURL             : "%v/php/jsmol.php",
      readyFunction         : jmol_isReady,
      script                : script_qsSup,
      disableInitialConsole : true,
      console               : "none",
    }

    function ReloadSup(mode) {
      Info_qsSup.use   = mode;
      jmolApplet_qsSup = Jmol.getApplet("jmolApplet_qsSup", Info_qsSup);
    }
  </script>
</head>

<body topmargin="5">
  <div name="sid" id="sid" style="font-family:Arial;text-align:right;color:#FF0000;font-size:1.0em;"></div>

  <script type="text/javascript">
    sid.innerHTML = (
      stru != "" ?
      "<font color=#0000FF><b>Query</b></font> <font color=#777777>vs</font> <b>Sbjct " + stru + "</b>" :
      "<font color=#0000FF><b>Query</b></font>"
    );
  </script>

  <script type="text/javascript">
    jmolApplet_qsSup = Jmol.getApplet("jmolApplet_qsSup", Info_qsSup);
  </script>

  <div style="position:fixed;bottom:5px;z-index:10000;">
    <button type="button" style="color:#0000FF;font-family:Arial;font-size:0.79em;font-weight:bold;"
            onClick="Jmol.script(jmolApplet_qsSup, 'restrict none; select :Q; cartoons');">
      Query
    </button>

    <button type="button" style="color:#FF0000;font-family:Arial;font-size:0.79em;font-weight:bold;"
            onClick="Jmol.script(jmolApplet_qsSup, 'restrict none; select :S; cartoons');">
      Sbjct
    </button>

    <button type="button" style="font-family:Arial;font-size:0.79em;"
            onClick="Jmol.script(jmolApplet_qsSup, 'restrict none; select :Q; color blue; backbone 0.5; select :S; color red; backbone 0.5');">
      Backbone
    </button>

    <button type="button" style="font-family:Arial;font-size:0.79em;"
            onClick="Jmol.script(jmolApplet_qsSup, 'set background white; set ambient 10; restrict none; select :Q; color blue; cartoons; select :S; color red; cartoons');">
      Reset
    </button>

    ||

    <button type="button" style="font-family:Arial;font-size:0.79em;"
            onClick="document.location='?m=HTML5&s=' + stru;">
      HTML5
    </button>

    <button type="button" style="font-family:Arial;font-size:0.79em;"
            onClick="document.location='?m=WEBGL&s=' + stru;">
      WEBGL
    </button>
  </div>
</body>
</html>
`

const HTML_SUMM_HEAD = `<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<!--
%v
-->
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>SARST2</title>
  <style type="text/css">
    .lnk:hover {
      color: #FF0000;
      cursor :pointer;
      text-decoration: underline;
    }
  </style>
</head>

<body>
  <pre>
`

const HTML_PAGE_HEAD = `<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<!--
%v
-->
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>SARST2</title>
  <style type="text/css">
    .lnk {
      color: #FF0000;
      font-weight: bold;
    }
    .lnk:hover {
      cursor :pointer;
      text-decoration: underline;
    }
  </style>
</head>

<body>
<pre>
<font size="5"><b>Page %v</b></font>
`

const HTML_TAIL = `</pre>
</body>
</html>
`