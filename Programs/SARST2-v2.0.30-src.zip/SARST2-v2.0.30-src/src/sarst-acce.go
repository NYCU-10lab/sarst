package main

import (
  "lo"
  "lo/bio/prot/stru"
  "lo/bio/prot/sequ"
  "strings"
  "math"
  "os"
  . "lo/bio/prot/stru/algos"
)


const NUM_PAGE_HITS     = 100
const NUM_SECTION_HITS  = 100

var sh = lo.PathSep

var hr________________________________________________________________________________ =
     "================================================================================" + br

var hd________________________________________________________________________________ =
     "--------------------------------------------------------------------------------" + br

var gbl_colNames =
     "Ranking  Protein                    Size Ident(%) ASize RMSD(Å) TM-score  Conf"   + br +
    hd________________________________________________________________________________

var Gbl_HtmlOut_Summ,
    Gbl_HtmlOut_Page    *lo.Writer



func ShowClues(showing_listsize_clue_breif, showing_listsize_clue_detail bool) {
  var clues string

  if showing_listsize_clue_breif {
    clues    = hr________________________________________________________________________________ +
               "*Argument '-brief' can be adjusted to show more hits with one-line summaries."    + br
  }

  if showing_listsize_clue_detail {
    if clues == "" {
      clues  = hr________________________________________________________________________________
    }
    clues   += "*Argument '-detail' can be adjusted to show more hits with detailed alignments."  + br
  }

  if clues != "" {
    lo.StdErr( lo.Csprint( 
      CYAN,
      clues + "*Please see '" + gbl_self + " -h' or the user manual for detailed usages."     + br +
      hr________________________________________________________________________________) + br,
    )
  }
}



func OutputResults(SR *SarstData) {
  numHits  := len(SR.Hits)
  pairwise := SR.IsPairwise()

  if pairwise {
    usr_brief_briefListSize, usr_detail_detailListSize = 0, 1
  }

  msg_nohomolg := br +
    hr________________________________________________________________________________ +
    "No homolog identified." + br +
    hr________________________________________________________________________________ + br

  if numHits == 0 {
    Gbl_Output.WriteString(msg_nohomolg)
    Gbl_Output.Flush()
    return
  }

  showing_listsize_clue_breif  := ( usr_brief_briefListSize   == DEFAULT_LISTSIZE_BRIEF )
  showing_listsize_clue_detail := ( usr_detail_detailListSize == DEFAULT_LISTSIZE_BRIEF )

  if usr_brief_briefListSize   > numHits {
    usr_brief_briefListSize    = numHits
  }

  if usr_detail_detailListSize > numHits {
    usr_detail_detailListSize  = numHits
  }


  //###
  if gbl_making_pssm {
    msg_noPssm := "(There was no hit bearing a lower pC-value than the -pssm_pC cutoff setting." + br +
                  " PSSM could not be made." + br +
                  " Setting a higher -pssm_pC cutoff may help.)" + br

    //##
    pssmText := SR.SarstPSSM()
    if pssmText == "" { pssmText = msg_noPssm }
    lo.WriteFile( strings.ReplaceAll(usr_pssm_out, "|", "sarst"), pssmText )

    //##
    pssmText  = SR.SsePSSM()
    if pssmText == "" { pssmText = msg_noPssm }
    lo.WriteFile( strings.ReplaceAll(usr_pssm_out, "|", "sse"  ), pssmText )

    //##
    pssmText  = SR.AacPSSM()
    if pssmText == "" { pssmText = msg_noPssm }
    lo.WriteFile( strings.ReplaceAll(usr_pssm_out, "-|", ""),  pssmText )

    //##
    pssmText  = SR.AatPSSM()
    if pssmText == "" { pssmText = msg_noPssm }
    lo.WriteFile( strings.ReplaceAll(usr_pssm_out, "|", "aat"), pssmText )
  }


  //###
  var file_htmlOut_summ, file_htmlOut_page  *os.File
  var pageFn             string
  var pageNo, pageNoLen  int

  qrySeq := string( sequ.ReadableAacSeq(SR.QryAacSeq) )

  if gbl_making_html {
    lo.MkDir(usr_html_dirHtmlOut)
    gbl_making_html = lo.Is_WritableDir(usr_html_dirHtmlOut)

    if gbl_making_html {
      usr_Sout_dirStrSup = usr_html_dirHtmlOut + sh + "sup"
      lo.MkDir(usr_Sout_dirStrSup)
      gbl_making_strSup = lo.Is_WritableDir(usr_Sout_dirStrSup)
      gbl_making_html   = gbl_making_strSup
    }
  }

  var qryPdbText string
  if gbl_making_strSup {
    lo.MkDir(usr_Sout_dirStrSup)
    gbl_making_strSup = lo.Is_WritableDir(usr_Sout_dirStrSup)
    if gbl_making_strSup {
      qryPdbText = stru.CAs2PdbText("Q", qrySeq, SR.QryCAs)
    }
  }

  if gbl_making_html {
    if usr_detail_detailListSize < usr_brief_briefListSize {
      if usr_detail_detailListSize != 0 { usr_detail_detailListSize = usr_brief_briefListSize }
    } else {
      usr_brief_briefListSize   = usr_detail_detailListSize
    }

    lo.WriteFile(usr_Sout_dirStrSup + sh + "Qry.pdb", qryPdbText)

    pageNoLen = int( math.Log10( float64(numHits/NUM_PAGE_HITS + 1) ) ) + 1

    file_htmlOut_summ = lo.FOpen(usr_html_dirHtmlOut + sh + "SarstResults-sum.html", "w")
    Gbl_HtmlOut_Summ  = lo.NewWriter(file_htmlOut_summ)
    Gbl_HtmlOut_Summ.WriteString(HTML_SUMM_HEAD)
  }


  //###
  qrySize     := int16( len(qrySeq) )
  qrySize_f64 := float64(qrySize)

  numSbjs     := SR.NumTotalSbjs()
  multiSbjs   := ( numSbjs > 1 )
  sbjSnLen    := byte( math.Log10( float64(usr_detail_detailListSize) ) ) + 1


  //###
  numPos  := lo.NumDigits(usr_brief_briefListSize)
  spacer1 := lo.IntMax(7 - numPos, 1)
  spacer2 := 32 - numPos - spacer1

  var i, numListedHits  int

  confScoreCut       := float32(usr_C_confScoreThresh)
  ordered_by_conf    := ( byte(usr_orderby) == ORDERBY_CONF    )
  ordered_by_TMscore := ( byte(usr_orderby) == ORDERBY_TMSCORE )

  if ( numHits > 1 || gbl_brief_provided ) && usr_brief_briefListSize > 0 ||
     numHits == 1 && usr_detail_detailListSize == 0 ||
     pairwise {

    var colNames string

    if !pairwise {
      Gbl_Output.WriteString( br +
        hr________________________________________________________________________________,
      )
    }

    if usr_q_quicklist {
      colNames =
       "Rank    Protein" + br +
        hd________________________________________________________________________________
    } else if !pairwise {
      colNames = gbl_colNames
    }

    if gbl_making_html {
      Gbl_HtmlOut_Summ.WriteString(
        hr________________________________________________________________________________,
      )
    }


    Hits := SR.Hits[0:usr_brief_briefListSize:usr_brief_briefListSize]
    if usr_detail_detailListSize == 0 { SR.Hits = Hits }

    var sbjSn int

    for i, SR.SbjData = range Hits {
      if i % NUM_SECTION_HITS == 0 {
        if usr_v_verbose && i != 0 {
          Gbl_Output.WriteString(hd________________________________________________________________________________)
        }
        if usr_v_verbose || i == 0 {
          Gbl_Output.WriteString(colNames)
        }

        if gbl_making_html {
          if i != 0 {
            Gbl_HtmlOut_Summ.WriteString(hd________________________________________________________________________________)
            Gbl_HtmlOut_Summ.Flush()
          }
          Gbl_HtmlOut_Summ.WriteString(gbl_colNames)
        }
      }

      aliSize, rmsd, tmQry, conf, pC, _ := SR.BasicAliResults()

      if multiSbjs {
        if gbl_C_provided  && conf < confScoreCut ||
           gbl_pC_provided && pC   > usr_pC_pCvalCut {
          if ordered_by_conf { break }
          continue
        }
        if tmQry < usr_tmcut_tmScoreCut {
          if ordered_by_TMscore { break }
          continue
        }
      }

      sbjSn++
      if sbjSn % NUM_PAGE_HITS == 1 {
        pageNo++
        pageFn = lo.Sprintf("SarstResults-%0*d.html", pageNoLen, pageNo)
      }

      ent := lo.Basename( SR.SbjFile() )
      if p:=strings.LastIndex(ent, ".");  p != -1  { ent = ent[0:p] }

      if usr_q_quicklist {
        Gbl_Output.WriteString( lo.Int2Str(sbjSn) + "\t" + ent + br )
        numListedHits++
        continue
      }


      ident := 100.0 * float64( SR.Iden() ) / qrySize_f64

      Gbl_Output.WriteString( lo.Sprintf(
        " %*d%*s %-*s %5d %7.2f %5d %7.4f  %7.4f %7.4f" + br,
        numPos, sbjSn, spacer1, "", spacer2,
        lo.SubStr(ent, 0, spacer2),
        SR.SbjSize(), ident, aliSize, rmsd,
        tmQry, conf,
      ) )

      numListedHits++

      if gbl_making_html {
        Gbl_HtmlOut_Summ.WriteString( lo.Sprintf(
          " <a class=\"lnk\" onClick=\"parent.sup.location='SarstResults-sup.html?s=%0*d';parent.page.location='" +
            pageFn +
            "#%0*d';\">%*d%*s %-*s</a> %5d %7.2f %5d %7.4f %8.4f %7.4f" + br,

          sbjSnLen, sbjSn,
          sbjSnLen, sbjSn,
          numPos, sbjSn, spacer1, "", spacer2,
          lo.SubStr(ent, 0, spacer2),
          SR.SbjSize(), ident, aliSize, rmsd,
          tmQry, conf,
        ) )
      }
    }

    if !pairwise {
      Gbl_Output.WriteString(hr________________________________________________________________________________ + br)
    }

    if gbl_making_html {
      Gbl_HtmlOut_Summ.WriteString(hr________________________________________________________________________________ + br)
    }

    Gbl_Output.Flush()
  }


  //###
  showing_listsize_clue_breif = ( showing_listsize_clue_breif && numListedHits == 500 )

  if usr_detail_detailListSize == 0 {
    ShowClues(showing_listsize_clue_breif, false)

    if gbl_making_html {
      Gbl_HtmlOut_Summ.Flush()
      file_htmlOut_summ.Close()
    }
    return
  }

  sequ.AacSM = SR.AacSM

  sep    := " "
  with_u := ( usr_nmusr_usrSize_to_norm > 0.0 )  
  with_d := ( usr_d_d0_scale            > 0.0 )

  if usr_nmavg_norm_by_avgSize || with_u { sep = "\t  " }

  numListedHits, pageNo = 0, 0

  var sbjSn int

  SR.Hits = SR.Hits[0:usr_detail_detailListSize:usr_detail_detailListSize]

  for _, SR.SbjData = range SR.Hits {
    SR.RestoreSwapData()

    aliSize, rmsd, tmQry, conf, pC, pCtext := SR.BasicAliResults()

    if multiSbjs {
      if gbl_C_provided  && conf < confScoreCut ||
         gbl_pC_provided && pC   > usr_pC_pCvalCut {
        if ordered_by_conf { break }
        continue
      }
      if tmQry < usr_tmcut_tmScoreCut {
        if ordered_by_TMscore { break }
        continue
      }
    }

    var qryAliStr, sbjAliStr, midAliStr  string
    var iden, simi                       int16

    sbjSn++
    SbjSeq  := sequ.ReadableAacSeq( SR.SbjAacSeq(SR.SbjData) )
    sbjSize := int16( len(SbjSeq) )

    if gbl_making_html && file_htmlOut_page == nil {
      pageNo++
      pageFn = lo.Sprintf("SarstResults-%0*d.html", pageNoLen, pageNo)

      file_htmlOut_page = lo.FOpen(usr_html_dirHtmlOut + sh + pageFn, "w")
      Gbl_HtmlOut_Page  = lo.NewWriter(file_htmlOut_page)
      Gbl_HtmlOut_Page.WriteString( lo.Sprintf(HTML_PAGE_HEAD, "", pageNo) )
    }


    if usr_sa_outputSeq {
      QaliPos, SaliPos := SR.SbjData.QAliPos.Slice(), SR.SbjData.SAliPos.Slice()
      qryAliStr, sbjAliStr, midAliStr, iden, simi = sequ.CodeTransAliStrs(
        qrySeq, string(SbjSeq),
        SR.QryAacSeq, SR.MakeAacSeq(SbjSeq),
        QaliPos, SaliPos,
      )
    } else {
      iden, simi = sequ.CodeTransAliIdenSimi(
        SR.QryAacSeq, SR.MakeAacSeq(SbjSeq),
        SR.SbjData.QAliPos.Slice(), SR.SbjData.SAliPos.Slice(),
      )
    }

    tmSbj, tmAvg, tmUsr_nl, d0Qry, d0Sbj, d0Avg, d0Usr, tmUsr_d0 := SR.SbjExtraAliResults()

    if multiSbjs {
      sbjTag := br + ">> " + lo.Int2Str(sbjSn) + br

      Gbl_Output.WriteString(sbjTag)

      if gbl_making_html {
        Gbl_HtmlOut_Page.WriteString(
          lo.Sprintf(`<a name="%0*d">` + sbjTag + `<a class="lnk" onClick="parent.sup.location='SarstResults-sup.html?s=%0*d';">`,
          sbjSnLen, sbjSn,
          sbjSnLen, sbjSn,
        ) )
      }
    }

    var sbjHead, sbjHead2  string
    if pairwise {
      sbjHead  = br + br
    } else {
      sbjHead2 = br
    }

    sbjHead += "## Sbjct: " + SR.SbjFile()

    Gbl_Output.WriteString(sbjHead)
    if gbl_making_html {
      Gbl_HtmlOut_Page.WriteString(sbjHead + `</a>`)
    }

    maxSize := qrySize
    if sbjSize > qrySize { maxSize = sbjSize }

    spanLen := lo.NumDigits( int(maxSize) )

    Output  := []byte( lo.Sprintf( "%s"      + br +
      "Protein length   = %-6d residues"     + br +
      "Aligned residues = %-6d residues"     + br +
      "RMSD             = %.4f Å"            + br +
      "Seq identity     = %-6.2f %% (%d/%d)" + br +
      "Seq similarity   = %-6.2f %% (%d/%d)" + br +
      "Confidence-score = %.4f"              + br +
      "pC-value         = %s"                + br + br +

      "TM-score, nQuery = %5.4f (norm size: %*d res," + sep + "d0: %*.2f Å)" + br,

      sbjHead2,
      sbjSize, aliSize, rmsd,
      100.0 * float64(iden) / qrySize_f64, iden, qrySize,
      100.0 * float64(simi) / qrySize_f64, simi, qrySize,
      conf, pCtext,

      tmQry, spanLen, qrySize, spanLen+1, d0Qry,
    ) )


    if usr_nmsbj_norm_by_sbjSize {
      Output = append( Output, lo.Sprintf(
        "TM-score, nSbjct = %5.4f (norm size: %*d res,"   + sep + "d0: %*.2f Å)" + br,
        tmSbj, spanLen, sbjSize, spanLen+1, d0Sbj,
      )... )
    }


    if usr_nmavg_norm_by_avgSize {
      Output = append( Output, lo.Sprintf(
        "TM-score, nAvg   = %5.4f (norm size: %*.2f res," + sep + "d0: %.2f Å)"  + br,
        tmAvg, spanLen, ( qrySize_f64 + float64(sbjSize) ) * 0.5, d0Avg,
      )... )
    }


    if with_u {        
      Output = append( Output, lo.Sprintf(
        "TM-score, nUser  = %5.4f (norm size: %*v res,"   + sep + "d0: %.2f Å)"  + br,
        tmUsr_nl, spanLen, usr_nmusr_usrSize_to_norm, d0Usr,
      )... )
    }


    if with_d {        
      Output = append( Output, lo.Sprintf(
        "TM-score, usr d0 = %5.4f (norm size: %*d res,"   + sep + "d0: %.2f Å)"  + br,
        tmUsr_d0, spanLen, qrySize, usr_d_d0_scale,
      )... )
    }


    if usr_sa_outputSeq {
      if usr_q_quicklist {
        Output = append( Output, br + "Query: " + qryAliStr + br + "Sbjct: " + sbjAliStr + br ... )
      } else {
        Output = append( Output, br + sequ.FormatAliStrs(qryAliStr, midAliStr, sbjAliStr, 60)... )
      }
    }


    //###
    if usr_mat_outputMat {
      Output = append( Output,    br +
        "Transformation matrix:" + br +
        "i            T[i]         U[i][0]         U[i][1]         U[i][2]" + br ...
      )
  
      for i := range 3 {
        Ri := SR.R[i]
        Output = append( Output, lo.Sprintf(
          "%d %15.10f %15.10f %15.10f %15.10f" + br, i, SR.T[i], Ri[0], Ri[1], Ri[2],
        )... )
      }
    }


    numListedHits++

    Gbl_Output.Write(Output)
    Gbl_Output.WriteString(br)
    Gbl_Output.Flush()

    if gbl_making_html {
      Gbl_HtmlOut_Page.Write(Output)
    }

    var supFile string

    if gbl_making_strSup {
      supFile = lo.Sprintf("%s%sQry-Sbj%0*d.pdb", usr_Sout_dirStrSup, sh, sbjSnLen, sbjSn)
      lo.WriteFile( supFile, qryPdbText + stru.CAs2PdbText( "S", string(SbjSeq), SR.GetSbjCAs() ) )
    }

    if gbl_making_html {
      if sbjSn % NUM_PAGE_HITS == 0 {
        Gbl_HtmlOut_Page.WriteString(HTML_TAIL)
        Gbl_HtmlOut_Page.Flush()
        file_htmlOut_page.Close()
        file_htmlOut_page = nil
      }
    }

    SR.ClearSwapData()
  }


  if numListedHits == 0 {
    Gbl_Output.WriteString(msg_nohomolg)
    Gbl_Output.Flush()
  } else {
    Gbl_Output.WriteString(br)
    Gbl_Output.Flush()

    showing_listsize_clue_detail = ( showing_listsize_clue_detail && numListedHits == 500 )
    ShowClues(showing_listsize_clue_breif, showing_listsize_clue_detail)
  }


  if gbl_making_html {
    Gbl_HtmlOut_Summ.WriteString(HTML_TAIL)
    Gbl_HtmlOut_Summ.Flush()
    file_htmlOut_summ.Close()

    Gbl_HtmlOut_Page.Flush()
    file_htmlOut_page.Close()


    lo.WriteFile( usr_html_dirHtmlOut + sh + "SarstResults.html",
      lo.Sprintf(
        HTML_RESULTS,
        "", pageNo, pageNo,
        "(v." + VER + ", build " + BUILD + ")",
        usr_qryPdbFile, lo.NumDigits(numSbjs), qrySize,
        lo.Number_Format( float64(numSbjs), 0, ".", "," ),
        SR.TargetList(usr_sbjPdbFilesPats),
      ),
    )

    lo.WriteFile( usr_html_dirHtmlOut + sh + "SarstResults-sup.html",
      lo.Sprintf(HTML_SUP, "", usr_jsmol_url, usr_jsmol_url, usr_jsmol_url, usr_jsmol_url, usr_jsmol_url),
    )
  }
}
