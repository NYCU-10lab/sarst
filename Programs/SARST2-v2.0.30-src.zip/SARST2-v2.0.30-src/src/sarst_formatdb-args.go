package main

import (
  "lo"
  "strings"
  . "lo/bio/prot/stru/algos"
)


func PrintHelp() {
  spacer := strings.Repeat( " ", len(gbl_self) )
  usage  := gbl_declaration + `
Usage: ` + gbl_self   + `  subject structure file(s)  -db database  [Options]
       ` + spacer + `  -------------------------      --------
       ` + spacer + `  > can be                       > Path to the database
       ` + spacer + `  1. multiple PDB/CIF files
       ` + spacer + `  2. folders containing
       ` + spacer + `     PDB/CIF files

Options:
  -db         [str]    The target database of subject structures to create.
                      (default: none)

  -flist      [str]    File list of subject structures. This argument can be
                       used along with common subject file arguments.
                      (default: none)

  -t          [int]    Number of threads.
                       It must be >= 0; 0 means all processors will be used.
                      (default: 0, all processors)

  -split      [int]    Split the database into subsets, each with the number of
                       subject structures specified by this option. Database
                       splitting helps prevent the database files from exceeding
                       the file size limit of the disk.
                      (default: none)

  -save_disk  [T/F]    Round the coordinates of atoms from three decimal places
                       into one decimal place to reduce disk usage.
                      (default: F)

  -keep_order [T/F]    Keep the order of the subject structures stored in the
                       database as their input order. Setting T may slow down
                       database creation.
                      (default: F)

  -h                   Print this help message.

================================================================================

Example usages:
  ` + gbl_self + ` "set1` + lo.PathSep + `*.pdb" "set2` + lo.PathSep + `*.cif" Sbj1.pdb Sbj2.cif -db mySarstDb
  ` + gbl_self + ` Sbj1.pdb Sbj2.cif Sbj3.pdb -db example` + lo.PathSep + `myProts.db -keep_order T
  ` + gbl_self + ` folder1 folder2 -db mySarstDb -save_disk T -split 50000


`

  lo.Exit( strings.ReplaceAll(usage, "\n", br) )
}



func ProcessArgs() map[interface{}]string {
  Flags := lo.GetCmdArgsMap(lo.Args)
  if len(Flags) < 1 { PrintHelp() }

  count_args := len(Flags)
  buffer     := count_args >> 1

  if buffer < 512 { buffer = 512 }
  Usr_SbjPdbFilesPats = make([]string, 0, buffer)

  for i:=1; i <= count_args; i++ {
    if val, got := Flags[i];  got {
      Usr_SbjPdbFilesPats = append(Usr_SbjPdbFilesPats, val)
    }
  }


  for flag, val := range Flags {
    switch flag {
      case "db"         : usr_db_targetDb     = val

      case "flist"      : usr_flist_file      = val

      case "t"          : usr_t_numThreads    = lo.Int(val)

      case "split"      : usr_split_subDbSize = lo.Int(val)

      case "save_disk"  : {
        usr_save_disk = ( ( val != "F" && val != "f" ) || val == NULL )

        if usr_save_disk && val != NULL && val != "T" && val != "t" {
          msg := lo.Csprint(
            MAGENTA,
            `Warning: Expected T/F for -save_disk, but received "` + val + `"; interpreting as T.` + br,
          )
          lo.Eprintf(msg)
        }
      }

      case "keep_order" : {
        usr_keep_order = ( ( val != "F" && val != "f" ) || val == NULL )

        if usr_keep_order && val != NULL && val != "T" && val != "t" {
          msg := lo.Csprint(
            MAGENTA,
            `Warning: Expected T/F for -keep_order, but received "` + val + `"; interpreting as T.` + br,
          )
          lo.Eprintf(msg)
        }
      }

      case "h": PrintHelp()

      default :
        if _, got := flag.(int); !got {
          Bye( lo.Sprint("Error: Unknown parameter -", flag, ".") )
        }
    }
  }


  return Flags
}



func CheckSettings(Flags map[interface{}]string) bool {
  if usr_flist_file != NULL {
    if !lo.Is_File(usr_flist_file) {
      gbl_errMsg = "Error: Invalid subject file list."
      return false
    }

    for sbjFilePat := range lo.FileLines(usr_flist_file) {
      sbjFilePat = strings.TrimSpace(sbjFilePat)
      if sbjFilePat == "" || sbjFilePat[0] == '#' { continue }

      Usr_SbjPdbFilesPats = append(Usr_SbjPdbFilesPats, sbjFilePat)
    }
  }


  if Usr_SbjPdbFilesPats == nil {
    gbl_errMsg = "Please provide the subject structure(s)."
    return false
  }

  Usr_SbjPdbFilesPats = Usr_SbjPdbFilesPats[ 0 : len(Usr_SbjPdbFilesPats) : len(Usr_SbjPdbFilesPats) ]
  lo.ReduceMem()


  //##
  if usr_db_targetDb == NULL || usr_db_targetDb == "" {
    gbl_errMsg = "Error: Please specify the target database to generate with the -db option."
    return false
  } else {
    dir, _, _ := lo.SplitPath(usr_db_targetDb)

    if dir != "" && !lo.Is_Dir(dir) {
      gbl_errMsg = "Error: Parent folder not found - " + strings.TrimRight(dir, "/\\")
      return false
    } else if datetime := lo.Date( "Y-m-d H:i:s", lo.Time() );
      lo.WriteFile(usr_db_targetDb, datetime)       == -1 ||
      lo.WriteFile(usr_db_targetDb + ".ver", DBVER) == -1 {
      gbl_errMsg = "Error: Cannot create the database (permission denied)."
      return false
    }
  }

  if lo.StrContains(usr_db_targetDb, "*") || lo.StrContains(usr_db_targetDb, "?") {
    gbl_errMsg = "Error: Invalid database name (* and ? are prohibited)."
    return false
  }

  if _, got := Flags[`split`];  got && usr_split_subDbSize <= 0 {
    gbl_errMsg = "Error: Wrong value for option -split!  It should be > 0."
    return false
  }

  if usr_t_numThreads < 0 {
    gbl_errMsg = "Error: Wrong value for option -t!  It should be >= 0 (0 for using all processors)."
    return false
  }

  if usr_t_numThreads == 0 {
    usr_t_numThreads = lo.NumCPUs()
  } else if usr_t_numThreads > 128 && usr_t_numThreads > lo.NumCPUs() * 8 {
    usr_t_numThreads = lo.NumCPUs() * 8
  }


  //##
  return true
}
