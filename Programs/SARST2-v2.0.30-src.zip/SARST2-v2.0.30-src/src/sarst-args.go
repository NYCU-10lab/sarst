package main

import (
  "lo"
  "strings"
  . "lo/bio/prot/stru/algos"
)


func PrintHelp() {
  gap := " "
  if lo.OS == "windows" { gap = "" }

  spacer := strings.Repeat( " ", len(gbl_self) )

  usage  := `
Usage: ` + gbl_self                             + gap + ` query structure file  subject structure file(s)  [Options]
       ` + strings.Repeat( " ", len(gbl_self) ) + gap + ` --------------------  -------------------------
       ` + spacer + gap + ` > a PDB/CIF file      > can be
       ` + spacer + gap + `                       1. a PDB/CIF file (pairwise alignment)
       ` + spacer + gap + `                       2. multiple PDB/CIF files
       ` + spacer + gap + `                       3. folders of PDB/CIF files
       ` + spacer + gap + `                       4. -db + pre-formatted target database

Options:
  -db     [str]    The target database of subject structures to search.
                  (default: none)

  -brief  [int]    Number of subject structures to show one-line summaries.
                  (default: 500)

  -detail [int]    Number of subject structures to show detailed alignment data.
                  (default: 500)

  -t      [int]    Number of threads.
                   Must be >= 0; 0 means all processors will be used.
                  (default: 0, all processors)

  -w      [int]    Word size.
                  (default: 5)

  -orderby         Sort the hit list by one of the following factors,
                   1: Conf-score--,
                   2: TM-score--,
                   3: sequence identity--, or
                   4: RMSD++,
                   where --/++ means descending/ascending order.
          [int]   (default: 1)
                  (ignored in a pairwise alignment)

  -mode   [int]    Search/alignment mode,
                   1: accurate,
                   2: balanced,
                   3: quick,
                   other values: auto (database search) or
                                 same as 1: accurate (pairwise alignment).
                  (default: auto for database search; 1 for pairwise alignment)

  -f      [int]    Enable minor filters, 0: off, 1: on, or other values: auto.
                  (default: auto)
                  (always 0, disabled, in a pairwise alignment)

  -C      [float]  Conf-score (confidence score) threshold for filtering
                   the final hit list.
                   Range: 0-1; 0 keeps all candidate homologs.
                  (default: 0.125)
                  (always disabled in a pairwise alignment)

  -pC     [float]  Cutoff of the pC-value, i.e., -log2(C), for filtering
                   the final hit list.
                   Must be >= 0; 0 keeps only perfect homologs.
                  (default: 3.0, equivalent to -C 0.125)
                  (always disabled in a pairwise alignment)

  -e      [float]  Cutoff of -log2(Conf-score) applied in each
                   filter and refinement step.
                   A smaller -e value discards more irrelevant hits.
                   Must be >= 0; 0 retrieves only perfect alignments.
                   This parameter significantly affects search results and
                   requires careful tuning.
                  (default: 1.0)
                  (always disabled in a pairwise alignment)

  -tmcut  [float]  TM-score cutoff.
                   Must be >= 0; 0 means no cutoff is applied.
                   TM-scores >= 0.7 by SARST2 might imply family-level homology.
                  (default: 0.15)
                  (always disabled in a pairwise alignment)

  -mem    [T/F]    Cache all subject protein data in memory.
                  (default: T)
                  (always T, enabled, in a pairwise alignment)

  -q      [T/F]    Quick output style.
                   Display results in a simplified, parser-friendly format.
                  (default: F)

  -sa     [T/F]    Display the structure-based sequence alignment.
                  (default: T)

  -mat    [T/F]    Display the transformation matrix for superimposition.
                  (default: F)

  -nmsbj  [T/F]    Normalize the TM-score by the size of the subject structure.
                  (default: F)

  -nmavg  [T/F]    Normalize the TM-score by the average size
                   of the query structure and each subject structure.
                  (default: F)

  -nmusr  [float]  The protein size for normalizing the TM-score.
                   It should be >= minimum size of the two structures;
                   otherwise, the TM-score may be > 1.

  -d      [float]  The d0 for scaling the TM-score, e.g., 5.0 Angstroms (Å).

  -ml     [T/F]    Apply machine learning.
                  (default: T)
                  (always F, disabled, in a pairwise alignment)

  -fdp    [str]    Dynamic programming algorithm for the filtering steps.
                   Supported options: NW (Needleman-Wunsch), SW (Smith-Waterman)
                  (default: NW)

  -rdp    [str]    Dynamic programming algorithm for the refinement step.
                   Supported options: NW (Needleman-Wunsch), SW (Smith-Waterman)
                  (default: NW)

  -swp    [str]    Path to the user-specified swap file.
                   Using a swap file can reduce the memory cost.
                  (default: none)

  -Sout   [str]    Folder to output the structure superimposition files.
                   The folder will be created if it does not exist.
                   The number of superimposition files is confined by
                   the -detail option.
                  (default: none)

  -html   [str]    Make an HTML output folder.
                   Superimposed structure files will also be generated
                   in the HTML folder.
                  (default: none)

  -jsmol  [str]    Set the path to the JSmol JavaScript package for
                   displaying superimposed structures in the HTML output.
                   It can be a local disk folder or an HTTP(S) URL.
                  (default: none)
                  (trial URL: "https://10lab.ceb.nycu.edu.tw/ext/jsmol")

  -pssm_out        File to store the PSSMs of the structural and sequence codes
                   applied in this algorithm.
          [str]   (default: none)

  -pssm_pC         The pC-value cutoff for PSSM construction.
          [float] (default: 0.05)

  -h               Print this help message.

================================================================================

Example usages:
# Pairwise alignment
  ` + gbl_self + ` Qry.pdb Sbj.pdb
  ` + gbl_self + ` Qry.pdb Sbj.cif

# One-against-all alignments
  ` + gbl_self + ` Qry.pdb Sbj1.pdb Sbj2.cif Sbj3.pdb -nmusr 100 -d 5.0 -sa F
  ` + gbl_self + ` Qry.pdb "set1` + lo.PathSep + `*.pdb" "set2` + lo.PathSep + `*.cif" Sbj1.pdb Sbj2.cif -d 5.0 -sa F

# Database search
  ` + gbl_self + ` Qry.pdb -db my_db` + lo.PathSep + `my_proteins.db -brief 10 -w 7 -e 0.1
  ` + gbl_self + ` Qry.pdb -db my_db` + lo.PathSep + `my_proteins.db -brief 10 -w 7 -e 0.1 -d 5.0 -sa F


`

  lo.Exit( gbl_declaration + strings.ReplaceAll(usage, "\n", br) )
}


func ProcessArgs() map[any]string {
  Flags    := lo.GetCmdArgsMap(lo.Args)
  numFlags := len(Flags)

  if numFlags < 3 { PrintHelp() }

  usr_qryPdbFile = Flags[1]

  for i:=2; i <= numFlags; i++ {
    if val, got := Flags[i];  got  { usr_sbjPdbFilesPats += val + "|" }
  }
  usr_sbjPdbFilesPats = strings.TrimRight(usr_sbjPdbFilesPats, "|")


  for flag, val := range Flags {
    val = strings.TrimSpace(val)

    switch flag {
      case "e", "C", "pC", "d", "w", "t", "db", "mode", "f",
           "orderby", "nmusr", "tmcut",
           "brief", "detail", "fdp", "Sout", "html",
           "jsmol", "pssm_out", "pssm_pC", "swp":
        if val == NULL {
          Bye( lo.Sprintf("Please provide a value for the -%v parameter.", flag) )
        }
    }

    switch flag {
      case "q" : usr_q_quicklist        = ( val == "T" || val == "t" || val == NULL )
      case "v" : usr_v_verbose          = ( val == "T" || val == "t" || val == NULL )

      case "e" : usr_e_evalCut          = lo.Float64(val)

      case "C" : usr_C_confScoreThresh  = lo.Float64(val); gbl_C_provided  = true
      case "pC": usr_pC_pCvalCut        = lo.Float64(val); gbl_pC_provided = true

      case "d" : usr_d_d0_scale         = lo.Float32(val)
      case "w" : usr_w_wordSize         = lo.Int16(val)
      case "t" : usr_t_numThreads       = lo.Int(val)

      case "db": {
        if sbjFile, got := Flags[2];  got {
          Bye( "Error:" + br +
               "User specified query      = " + usr_qryPdbFile + br +
               "User specified subject(s) = " + sbjFile + br   + br +
               "The option -db is not applicable as the subject structure(s) is specified (listed above)." )
        }
        usr_db_targetDb = val
      }

      case "mode"      : usr_mode_runningMode      = lo.Int8(val)

      case "f"         : usr_f_minorFiltersMode    = lo.Int8(val)

      case "orderby"   : usr_orderby               = lo.Int8(val)

      case "nmsbj"     : usr_nmsbj_norm_by_sbjSize = (   val == "T" || val == "t"   || val == NULL )

      case "nmavg"     : usr_nmavg_norm_by_avgSize = (   val == "T" || val == "t"   || val == NULL )

      case "nmusr"     : usr_nmusr_usrSize_to_norm = lo.Float32(val)

      case "sa"        : usr_sa_outputSeq          = ( ( val != "F" && val != "f" ) || val == NULL )

      case "mat"       : usr_mat_outputMat         = (   val == "T" || val == "t"   || val == NULL )

      case "mem"       : usr_mem_memCache          = ( ( val != "F" && val != "f" ) || val == NULL )
                         gbl_mem_provided          = true

      case "ml"        : usr_ml_enabled            = ( ( val != "F" && val != "f" ) || val == NULL )

      case "tmcut"     : usr_tmcut_tmScoreCut      = lo.Float32(val)

      case "brief"     : usr_brief_briefListSize   = int( lo.Float64(val) )
                         gbl_brief_provided        = ( usr_brief_briefListSize   != DEFAULT_HITLIST_SIZE )

      case "detail"    : usr_detail_detailListSize = int( lo.Float64(val) )
                         gbl_detail_provided       = ( usr_detail_detailListSize != DEFAULT_HITLIST_SIZE )

      case "fdp"       : usr_fdp_filterDpAlgo      = strings.ToLower(val)
      case "rdp"       : usr_rdp_refineDpAlgo      = strings.ToLower(val)

      case "Sout"      : usr_Sout_dirStrSup        = val
                         gbl_making_strSup         = true

      case "html"      : usr_html_dirHtmlOut       = val
                         gbl_making_html           = true

      case "jsmol"     : usr_jsmol_url             = val

      case "pssm_out"  : usr_pssm_out              = val
                         gbl_making_pssm           = true

      case "pssm_pC"   : usr_pssm_ecut             = lo.Float64(val)

      case "swp"       : usr_swp_file              = val

      case "h": PrintHelp()

      default :
        if _, got := flag.(int);  !got  {
          Bye( lo.Sprint("Error: Unknown parameter -", flag, ".") )
        }
    }
  }

  return Flags
}


func CheckSettings(Flags map[any]string) bool {
  if usr_qryPdbFile == "" {
    gbl_errMsg = "Please provide the query structure."
    return false
  }    

  if usr_sbjPdbFilesPats == "" && usr_db_targetDb == "" {
    gbl_errMsg = "Please provide the subject structure(s) or a SARST-formatted target database."
    return false
  }


  //###
  if _, got := Flags[`e`];  got && usr_e_evalCut < 0.0 {
    gbl_errMsg = "Error: Invalid value for option -e. It should be >= 0.0; 0.0 retrieves only perfect alignments."
    return false
  }

  switch {
    case gbl_pC_provided && gbl_C_provided : {
      gbl_errMsg = "Error: Options -C and -pC cannot be set simultaneously."
      return false
    }

    case gbl_pC_provided : {
      if usr_pC_pCvalCut < 0.0 {
        gbl_errMsg = lo.Sprintf("Error: Invalid value for option -pC. It should be >= 0.0; 0.0 keeps only perfect homologs.")
        return false
      }
    }

    case gbl_C_provided : {
      if usr_C_confScoreThresh < 0.0 || usr_C_confScoreThresh > 1.0 {
        gbl_errMsg = lo.Sprintf("Error: Invalid value for option -C. It should be >= 0.0 and <= 1.0; 0.0 keeps all candidate homologs.")
        return false
      }
    }
  }


  if _, got := Flags[`mode`];  got && usr_mode_runningMode < 0  {
    gbl_errMsg = "Error: Invalid value for option -mode." + br + "It should be >= 0 (1: accurate, 2: balanced, 3: quick, other values: auto)."
    return false
  }

  if _, got := Flags[`f`];  got && usr_f_minorFiltersMode < 0  {
    gbl_errMsg = "Error: Invalid value for option -f. It should be >= 0 (0: off, 1: on, other values: auto)."
    return false
  }

  if _, got := Flags[`orderby`];  got && ( usr_orderby < 1 || usr_orderby > 4 )  {
    gbl_errMsg = "Error: Invalid value for option -orderby." + br + "It should be an integer between 1 and 4." + br + "1: Conf-score--, 2: TM-score--, 3: sequence identity--, or 4: RMSD++."
    return false
  }

  if _, got := Flags[`w`];  got && ( usr_w_wordSize < 1 || usr_w_wordSize > MAX_USR_WORD_SIZE )  {
    gbl_errMsg = lo.Sprintf("Error: Invalid value for option -w. It should be between 1 and %d.", MAX_USR_WORD_SIZE)
    return false
  }

  if _, got := Flags[`t`];  got  {
    if usr_t_numThreads < 0 {
      gbl_errMsg = "Error: Invalid value for option -t. It should be >= 0 (0 for using all processors)."
      return false
    }
  }

  if _, got := Flags[`d`];  got && usr_d_d0_scale < 1.0  {
    gbl_errMsg = "Error: Invalid value for option -d. It should be >= 1.0"
    return false
  }

  if _, got := Flags[`nmavg`];  got && Flags[`nmavg`] != "T" && Flags[`nmavg`] != "F" && Flags[`nmavg`] != NULL  {
    gbl_errMsg = "Error: Invalid value for option -nmavg. It should be T or F"
    return false
  }

  if _, got := Flags[`nmusr`];  got && usr_nmusr_usrSize_to_norm < 1.0  {
    gbl_errMsg = "Error: Invalid value for option -nmusr. It should be >= 1.0"
    return false
  }

  if _, got := Flags[`m`];  got && Flags[`m`] != "T" && Flags[`m`] != "F" && Flags[`m`] != NULL  {
    gbl_errMsg = "Error: Invalid value for option -m. It should be T or F"
    return false
  }

  if usr_tmcut_tmScoreCut < 0.0 {
    gbl_errMsg = "Error: Invalid value for option -tmcut. It should be >= 0"
    return false
  }

  if usr_brief_briefListSize < 0 {
    gbl_errMsg = "Error: Invalid value for option -brief. It should be >= 0"
    return false
  }

  if usr_detail_detailListSize < 0 {
    gbl_errMsg = "Error: Invalid value for option -detail. It should be >= 0"
    return false
  }

  if usr_brief_briefListSize + usr_detail_detailListSize == 0 {
    gbl_errMsg = "Error: Options -brief and -detail cannot be both 0."
    return false
  }

  if _, got := Flags[`fdp`];  got  {
    if usr_fdp_filterDpAlgo != "nw" && usr_fdp_filterDpAlgo != "sw" {
      gbl_errMsg = "Error: Invalid setting for option -fdp. Only NW and SW are supported."
      return false
    }
  }

  if _, got := Flags[`rdp`];  got  {
    if usr_rdp_refineDpAlgo != "nw" && usr_rdp_refineDpAlgo != "sw" {
      gbl_errMsg = "Error: Invalid setting for option -rdp. Only NW and SW are supported."
      return false
    }
  }

  if _, got := Flags[`swp`];  got && usr_detail_detailListSize > 0  {
    if usr_swp_file == NULL {
      gbl_errMsg = "Error: Invalid swap file setting."
      return false
    }

    if usr_mem_memCache {
      if gbl_mem_provided {
        gbl_errMsg = "Error: Options Swap (-swp) and memory cache (-mem) cannot be enabled simultaneously."
        return false
      }
      usr_mem_memCache = false
    }

    Fp := lo.FOpen(usr_swp_file, "a")
    if Fp == nil {
      gbl_errMsg = "Error: Failed to open the swap file."
      return false
    }
    Fp.Close()
  }

  if usr_mode_runningMode > 3 {
    usr_mode_runningMode = 0
  }

  if usr_t_numThreads == 0 {
    usr_t_numThreads = lo.NumCPUs()
  } else if usr_t_numThreads > 128 && usr_t_numThreads > lo.NumCPUs() * 8 {
    usr_t_numThreads = lo.NumCPUs() * 8
  }


  //###
  if usr_nmsbj_norm_by_sbjSize && usr_nmusr_usrSize_to_norm > 0.0 {
    gbl_errMsg = "Error: Options -nmsbj and -nmusr cannot be set simultaneously."
    return false
  }

  if usr_nmavg_norm_by_avgSize && usr_nmusr_usrSize_to_norm > 0.0 {
    gbl_errMsg = "Error: Options -nmavg and -nmusr cannot be set simultaneously."
    return false
  }

  if usr_nmsbj_norm_by_sbjSize && usr_nmavg_norm_by_avgSize {
    gbl_errMsg = "Error: Options -nmsbj and -nmavg cannot be set simultaneously."
    return false
  }

  if _, got := Flags[`Sout`];  got  {
    if _, got := Flags[`html`];  got  {
      gbl_errMsg = "Error: Options -Sout and -html cannot be set simultaneously, for the HTML output folder will contain the superimposition files."
      return false
    }
  }

  if gbl_making_html {
    if usr_jsmol_url == "" || usr_jsmol_url == NULL {
      gbl_errMsg = "Error: Please also specify, via the -jsmol option, the disk path or HTTP(S) URL to the JSmol package," + br +
                   "which is required for displaying 3D structural objects in the HTML output page." + br + br + 
                   `(URL: "https://10.life.nctu.edu.tw/ext/jsmol")`
      return false
    } else if url := strings.ToLower(usr_jsmol_url); !strings.HasPrefix(url, "http://") && !strings.HasPrefix(url, "https://") {
      url = lo.RealPath(usr_jsmol_url)
      if url == "" { url = usr_jsmol_url }
      usr_jsmol_url = "file:///" + url
    }
  }

  if gbl_making_pssm {
    if usr_pssm_out == "" || usr_pssm_out == NULL {
      gbl_errMsg = "Error: Invalid setting for option -pssm_out."
      return false
    }
    
    ext := lo.FileExt(usr_pssm_out)
    ep  := len(usr_pssm_out) - len(ext)

    usr_pssm_out = usr_pssm_out[0:ep] + "-|" + usr_pssm_out[ep:]

    if usr_pssm_ecut < 0.0 {
      gbl_errMsg = "Error: Invalid value for option -pssm_pC. It should be >= 0"
      return false
    }
  }

  return true
}
