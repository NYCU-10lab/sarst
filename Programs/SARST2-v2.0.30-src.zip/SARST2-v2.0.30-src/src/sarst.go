package main

import (
  "lo"
  . "lo/bio/prot/stru/algos"
)


const (
  DEFAULT_LISTSIZE_BRIEF      = 500
  DEFAULT_LISTSIZE_DETAIL     = 500
)


var gbl_self                  = "." + lo.PathSep + "sarst2"

var gbl_brief_provided,
    gbl_detail_provided,
    gbl_C_provided, gbl_pC_provided,
    gbl_mem_provided,
    gbl_making_strSup,
    gbl_making_html,
    gbl_making_pssm           bool

var usr_qryPdbFile,
    usr_sbjPdbFilesPats,
    usr_db_targetDb,
    usr_Sout_dirStrSup,
    usr_html_dirHtmlOut,
    usr_jsmol_url,
    usr_swp_file,
    usr_pssm_out              string

var usr_nmusr_usrSize_to_norm,
    usr_d_d0_scale            float32

var usr_nmsbj_norm_by_sbjSize,
    usr_nmavg_norm_by_avgSize,
    usr_mat_outputMat,
    usr_q_quicklist,
    usr_v_verbose             bool

var usr_e_evalCut             float64 = 1.00
var usr_C_confScoreThresh     float64 = 0.50
var usr_pC_pCvalCut           float64 = 1.00
var usr_pssm_ecut             float64 = 0.05
var usr_tmcut_tmScoreCut      float32 = 0.15

var usr_w_wordSize            int16   = 5
var usr_mode_runningMode      int8    = 0
var usr_f_minorFiltersMode    int8    = 2
var usr_orderby               int8    = 1

var usr_brief_briefListSize   = DEFAULT_LISTSIZE_BRIEF
var usr_detail_detailListSize = DEFAULT_LISTSIZE_DETAIL
var usr_mem_memCache          = true
var usr_sa_outputSeq          = true
var usr_ml_enabled            = true

var usr_fdp_filterDpAlgo      = "nw"
var usr_rdp_refineDpAlgo      = "nw"

var usr_t_numThreads          = 0



func main() {
  if UsrSettings := ProcessArgs();
     !CheckSettings(UsrSettings) { Bye(gbl_errMsg) }

  lo.ErrorReporting = 0


  //###
  filterDp := NWDP
  if usr_fdp_filterDpAlgo == "sw" { filterDp = SWDP }

  refineDp := NWDP
  if usr_rdp_refineDpAlgo == "sw" { refineDp = SWDP }

  Settings := map[string]any{
    `using_memCache`   : usr_mem_memCache,
    `normLen_usr`      : usr_nmusr_usrSize_to_norm,
    `d0_usr`           : usr_d_d0_scale,
    `normBySbj`        : usr_nmsbj_norm_by_sbjSize,
    `normByAvg`        : usr_nmavg_norm_by_avgSize,
    `keeping_sbjCAs`   : ( gbl_making_strSup || gbl_making_html ),
    `making_pssm`      : ( usr_pssm_out != "" ),
    `quickListMode`    : usr_q_quicklist,

    `wordSize`         : usr_w_wordSize,
    `numThreads`       : usr_t_numThreads,
    `evalCut`          : usr_e_evalCut,
    `tmScoreCut`       : usr_tmcut_tmScoreCut,
    `briefListSize`    : usr_brief_briefListSize,
    `detailListSize`   : usr_detail_detailListSize,

    `pssmEvalCut`      : usr_pssm_ecut,
    `swpFile`          : usr_swp_file,

    `using_ML`         : usr_ml_enabled,
    `filterDp`         : filterDp,
    `refineDp`         : refineDp,

    `runningMode`      : byte(usr_mode_runningMode),
    `minorFiltersMode` : byte(usr_f_minorFiltersMode),
    `orderBy`          : byte(usr_orderby),
  }


  if usr_q_quicklist {
    Gbl_Output.WriteString(gbl_declaration_brief)
  } else {
    Gbl_Output.WriteString(gbl_declaration      )
  }
  Gbl_Output.Flush()

  SR := Sarst(usr_qryPdbFile, usr_sbjPdbFilesPats, usr_db_targetDb, Settings, Gbl_Output)
  Gbl_Output.Flush()


  //###
  OutputResults(SR)

  if SR.ErrMsg() != "" {
    if SR.Hits != nil {
      Gbl_Output.WriteString( hd________________________________________________________________________________ )
    } else {
      Gbl_Output.WriteString( br )
    }

    Gbl_Output.WriteString(   SR.ErrMsg() + br   )

    if SR.Hits != nil {
      Gbl_Output.WriteString( hd________________________________________________________________________________ + br )
    } else {
      Gbl_Output.WriteString( br )
    }
  }

  Gbl_Output.WriteString ( lo.Csprintf( YELLOW, "Running time: %.4f sec" + br, lo.Timefrom(gbl_time_init) ) )

  SR.Close()
}
