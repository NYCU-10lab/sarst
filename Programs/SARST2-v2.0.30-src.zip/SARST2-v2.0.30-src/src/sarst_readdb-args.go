package main

import (
  "lo"
  "strings"
  . "lo/bio/prot/stru/algos"
)



func PrintHelp() {
  spacer := strings.Repeat( " ", len(gbl_self) )
  usage  := gbl_declaration + `
Usage: ` + gbl_self   + `  target database  output file  [-seq sequence type]
       ` + spacer + `  ---------------  -----------        -------------
       ` + spacer + `  > must be SARST2 > will be in       > can be
       ` + spacer + `    pre-formatted    FASTA format     1. AA
       ` + spacer + `                                      2. AAT
       ` + spacer + `                                      3. SARST
       ` + spacer + `                                      4. SSE

Options:
  -seq [str]  The output sequence type.
              AA       amino acid sequence
              AAT      five-symbol amino acid type sequence
              SARST    SARST Ramachandran-code sequence
              SSE      four-symbol secondary structure element sequence
             (default: AA)

  -h          Print this help message.

================================================================================

Example usages:
  ` + gbl_self + ` my_db` + lo.PathSep + `my_proteins.db seqs.fasta
  ` + gbl_self + ` my_db` + lo.PathSep + `my_proteins.db seqs.fasta -seq SARST
  ` + gbl_self + ` my_db` + lo.PathSep + `my_proteins.db seqs.fasta -seq AAT

`

  lo.Exit( strings.ReplaceAll(usage, "\n", br) )
}



func ProcessArgs() map[interface{}]string {
  Flags := lo.GetCmdArgsMap(lo.Args)
  if len(Flags) < 2 { PrintHelp() }

  usr_targetDb   = Flags[1]
  usr_outputFile = Flags[2]

  for flag, val := range Flags {
    switch flag {
      case "seq":
        if val == NULL {
          Bye( lo.Sprintf("Please provide a value for the -%v parameter.", flag) )
        }
        usr_seq_seqType = strings.ToLower(val)

      case "h":
        PrintHelp()

      default :
        if idx, got := flag.(int); !got {
          Bye( lo.Sprint("Error: Unknown parameter -", flag, ".") )
        } else if idx > 2 {
          Bye( lo.Sprint("Error: Unknown additional argument '", val, "'.") )
        }
    }
  }

  return Flags
}



func CheckSettings(Flags map[interface{}]string) bool {
  if usr_targetDb == "" {
    gbl_errMsg = "Please provide the SARST database."
    return false
  }

  if usr_outputFile == "" {
    gbl_errMsg = "Please specify the output file."
    return false
  }

  return true
}
