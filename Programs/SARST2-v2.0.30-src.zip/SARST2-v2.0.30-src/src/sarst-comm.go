package main

import (
  "lo"
)


const (
  YELLOW                = "1;33"
  MAGENTA               = "1;35"
  CYAN                  = "1;36"
)


var gbl_time_init       = lo.Nanotime()
var Gbl_Output          = lo.Stdout
var br                  = lo.BR

var gbl_errMsg          string



func Bye(msg string) {
  if msg != "" { lo.Exit(br + msg + br + br) }
  lo.Exit()
}
