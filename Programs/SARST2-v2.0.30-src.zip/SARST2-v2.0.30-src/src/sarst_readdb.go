package main

import (
  "lo"
  . "lo/bio/prot/stru/algos"
)


var gbl_self            = "." +lo.PathSep + "readdb"

var usr_seq_seqType     string = AA_SEQ

var usr_targetDb,
    usr_outputFile      string



func main() {
  if UsrSettings := ProcessArgs();
     !CheckSettings(UsrSettings) { Bye(gbl_errMsg) }

  lo.ErrorReporting = 0
  lo.Println(gbl_declaration)

  SR := ReadDb(usr_targetDb, usr_seq_seqType, usr_outputFile, Gbl_Output)
  if SR.ErrMsg() != "" { Bye( SR.ErrMsg() ) }

  lo.Cprint( YELLOW, lo.Sprintf( "Running time: %.4f sec\n", lo.Timefrom(gbl_time_init) ) )
}
