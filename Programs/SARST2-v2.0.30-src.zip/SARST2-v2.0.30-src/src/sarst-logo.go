package main

import (
  "lo"
  "strings"
  . "lo/bio/prot/stru/algos"
)


var gbl_declaration        = strings.ReplaceAll(SARST_BANNER,       "\n", br)
var gbl_declaration_brief  = strings.ReplaceAll(SARST_BANNER_SHORT, "\n", br)



func init() {
  if lo.OS != "windows" { return }

  gbl_declaration = strings.ReplaceAll(gbl_declaration, "╔", "+")
  gbl_declaration = strings.ReplaceAll(gbl_declaration, "╚", "+")
  gbl_declaration = strings.ReplaceAll(gbl_declaration, "╗", "+")
  gbl_declaration = strings.ReplaceAll(gbl_declaration, "╝", "+")
  gbl_declaration = strings.ReplaceAll(gbl_declaration, "═", "-")
  gbl_declaration = strings.ReplaceAll(gbl_declaration, "║", "|")

  gbl_declaration_brief = strings.ReplaceAll(gbl_declaration_brief, "╔", "+")
  gbl_declaration_brief = strings.ReplaceAll(gbl_declaration_brief, "╚", "+")
  gbl_declaration_brief = strings.ReplaceAll(gbl_declaration_brief, "╗", "+")
  gbl_declaration_brief = strings.ReplaceAll(gbl_declaration_brief, "╝", "+")
  gbl_declaration_brief = strings.ReplaceAll(gbl_declaration_brief, "═", "-")
  gbl_declaration_brief = strings.ReplaceAll(gbl_declaration_brief, "║", "|")

  gbl_self += ".exe"
}
