
+------------------------------------------------------------------------------+
|  ____    _    ____  ____ _____ ____                                          |
| / ___|  / \  |  _ \/ ___|_   _|___ \       Structural similarity search      |
| \___ \ / _ \ | |_) |___ \ | |   __) |                Aided by                |
|  ___) | ___ \|    / ___) || |  / __/  Ramachandran Sequential Transformation |
| |____/_/   \_\_|\_\|____/ |_| |_____|        (v2.0.30, build 20250609)       |
|                                                                              |
+------------------------------------------------------------------------------+


=========================
 About this program
=========================

SARST2 is a high-performance protein structure alignment algorithm for
structural similarity searches. It supports both large-scale database searches
using a given query protein and pairwise alignments between two structures.


=========================
 How to build
=========================

SARST2 can be compiled with Golang v1.22.5 or later on Linux, macOS, Windows,
or any other platform supported by Golang.

There are three main programs that must be compiled for the SARST2 package
to be fully functional. The compilation commands are as follows:

# sarst2
go build -gcflags="all=-B" -ldflags="-w -s"  -o sarst2 \
src/sarst.go src/sarst-args.go src/sarst-acce.go src/sarst-html.go \
src/sarst-comm.go src/sarst-logo.go

# formatdb
go build -gcflags="all=-B" -ldflags="-w -s"  -o formatdb \
src/sarst_formatdb.go src/sarst_formatdb-args.go \
src/sarst-comm.go src/sarst-logo.go

# readdb
go build -gcflags="all=-B" -ldflags="-w -s"  -o readdb \
src/sarst_readdb.go src/sarst_readdb-args.go \
src/sarst-comm.go src/sarst-logo.go

Before building these programs, you need to install the Golang programming
environment and obtain required packages. Alternatively, you may use an
online compiler provided by our team, which was established for educational
purposes and is available for non-commercial use.

If you encounter any issues when compiling SARST2, please contact:
WadeLo@nycu.edu.tw


=========================
 How to cite SARST2
=========================

Please cite our papers should you find this software helpful,

1. Wei-Cheng Lo, Po-Jung Huang, Chih-Hung Chang and Ping-Chiang Lyu (2007, Aug).
Protein structural similarity search by Ramachandran codes. BMC Bioinformatics,
8:307.

2. Wei-Cheng Lo, Che-Yu Lee, Chi-Ching Lee and Ping-Chiang Lyu* (2009, Jul).
iSARST: an integrated SARST web server for rapid protein structural similarity
searches. Nucleic Acids Research, 37:W545-51.


=========================
 Contact information
=========================

SARST2 is maintained by the 10 Lab,
Institute of Bioinformatics and Systems Biology,
National Yang Ming Chiao Tung University, Hsinchu, Taiwan

Official website:
https://10lab.ceb.nycu.edu.tw/sarst2

If you have any inquiries or questions, please feel free to contact us at:
WadeLo@nycu.edu.tw

