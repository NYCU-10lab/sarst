
+------------------------------------------------------------------------------+
|  ____    _    ____  ____ _____ ____                                          |
| / ___|  / \  |  _ \/ ___|_   _|___ \       Structural similarity search      |
| \___ \ / _ \ | |_) |___ \ | |   __) |                Aided by                |
|  ___) | ___ \|    / ___) || |  / __/  Ramachandran Sequential Transformation |
| |____/_/   \_\_|\_\|____/ |_| |_____|        (v2.0.30, build 20250609)       |
|                                                                              |
+------------------------------------------------------------------------------+


=========================
 Contents of the folders
=========================

bin   64-bit compiled executables for Linux, macOS, and Windows.

dat   Example PDB and SCOP test files.

doc   Detailed user manuals in multiple languages.


=========================
 About this program
=========================

SARST2 is a high-performance protein structure alignment algorithm for
structural similarity searches. It supports both large-scale database searches
using a given query protein and pairwise alignments between two structures.


=========================
 How to download and use
=========================

The SARST2 program and pre-formatted target databases are frequently updated.
The latest version is available at: https://10lab.ceb.nycu.edu.tw/sarst2

After downloading a compressed SARST2 archive (tar.gz or zip format), extract
the files using the appropriate utility (tar, gzip, or unzip).

For brief usage information, run the SARST2 executable with the -h option.

# Linux/macOS:
./sarst2
./sarst2 -h

# Windows:
.\sarst2.exe
.\sarst2.exe -h

For detailed manuals, please see the SARST2-UserManual-LANGUAGE.pdf files in
the doc folder.


=========================
 Example usage
=========================

On a Linux machine, from within the "dat" folder, you may test SARST2 without
using a pre-formatted database by running the following command:

----------
cd dat
../bin/sarst2 101mA.pdb "PDB-sample/*.pdb" -t 6
----------

Here, 101mA.pdb is the query structure, "PDB-sample/*.pdb" are the subject
structures, and the -t argument specifies that 6 threads will be used
for the structural similarity search.

There are 100 structure files in the PDB-sample folder. Using 6 threads,
a typical SARST2 search on 3.3 GHz CPUs takes < 0.05 sec.

Using a pre-formatted database accelerates the similarity search and
significantly reduces disk usage for storing structural data. For example,
storing all the CIF files of the AlphaFold Protein Structure Database
(214 million structures) requires 59.7 TB, but a pre-formatted SARST2
AlphaFold Database requires only 0.5 TB. To test SARST2 with a
pre-formatted database, try the following commands:

----------
../bin/formatdb "PDB-sample/*.pdb" -db MyPDB.tdb -t 6
../bin/sarst2 101mA.pdb -db MyPDB.tdb -t 6
----------

The formatdb command is needed only once, and the resulting target database
(MyPDB.tdb) can be reused for future searches. There are 100 structures
in MyPDB.tdb. Using 6 threads, a typical SARST2 search against it on 3.3 GHz
CPUs takes < 0.03 sec.

On a standard desktop computer with 3.3 GHz CPUs and 16 GB RAM, a typical
SARST2 search against the 2022 Protein Data Bank (~0.7 million structures)
takes < 1.0 sec. A search against the AlphaFold Database takes < 1.2 min
if advanced parameters are not specified.


=========================
 How to cite SARST2
=========================

Please cite our papers should you find this software helpful,

1. Wei-Cheng Lo*, Arieh Warshel, Chia-Hua Lo, Chia Yee Choke, Yan-Jie Li,
Shih-Chung Yen, Jyun-Yi Yang and Shih-Wen Weng (2025, Sep).
SARST2 high-throughput and resource-efficient protein structure alignment
against massive databases, DOI: 10.1038/s41467-025-63757-9.

2. Wei-Cheng Lo, Che-Yu Lee, Chi-Ching Lee and Ping-Chiang Lyu* (2009, Jul).
iSARST: an integrated SARST web server for rapid protein structural similarity
searches. Nucleic Acids Research, DOI: 10.1093/nar/gkp291.

3. Wei-Cheng Lo, Po-Jung Huang, Chih-Hung Chang and Ping-Chiang Lyu (2007, Aug).
Protein structural similarity search by Ramachandran codes. BMC Bioinformatics,
DOI: 10.1186/1471-2105-8-307.


=========================
 Contact information
=========================

SARST2 is maintained by the 10 Lab,
Institute of Bioinformatics and Systems Biology,
National Yang Ming Chiao Tung University, Hsinchu, Taiwan

Official website:
https://10lab.ceb.nycu.edu.tw/sarst2

If you have any inquiries or questions, please feel free to contact us at:
WadeLo@nycu.edu.tw

